package com.gamebooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var list: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var showAll = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32)
            setBackgroundColor(Color.parseColor("#0E0E12"))
        }
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        val perm = Button(this).apply {
            text = "Ativar acesso de uso (reabrir jogo que fecha)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        val toggle = Button(this).apply {
            text = "Mostrar todos os apps"
            setOnClickListener { showAll = !showAll; text = if (showAll) "Mostrar só jogos" else "Mostrar todos os apps"; refresh() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(info); root.addView(perm); root.addView(toggle)
        root.addView(TextView(this).apply { text = "Taxa de atualização (Hz) – só liberado o que a tela suporta"; setTextColor(Color.WHITE); setPadding(0, 24, 0, 8) })
        root.addView(hzGrid())
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)
        refresh(); tick.run()
    }

    private val hzOptions = listOf(60, 90, 100, 120, 144, 165, 200, 240, 300, 400, 500, 600, 700, 800, 900, 1000)

    private fun supportedHz(): Set<Int> =
        windowManager.defaultDisplay.supportedModes.map { Math.round(it.refreshRate) }.toSet()

    private fun hzGrid(): GridLayout {
        val ok = supportedHz()
        return GridLayout(this).apply {
            columnCount = 4
            hzOptions.forEach { hz ->
                addView(Button(this@MainActivity).apply {
                    text = "$hz"
                    isEnabled = hz in ok
                    setOnClickListener { setHz(hz) }
                })
            }
        }
    }

    private fun setHz(hz: Int) {
        if (!Settings.System.canWrite(this)) {
            Toast.makeText(this, "Permita 'Modificar configurações do sistema' e toque de novo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            return
        }
        try {
            Settings.System.putFloat(contentResolver, "min_refresh_rate", hz.toFloat())
            Settings.System.putFloat(contentResolver, "peak_refresh_rate", hz.toFloat())
        } catch (e: Exception) { Toast.makeText(this, "Seu aparelho bloqueou a troca de Hz", Toast.LENGTH_LONG).show() }
        val mode = windowManager.defaultDisplay.supportedModes.firstOrNull { Math.round(it.refreshRate) == hz }
        if (mode != null) window.attributes = window.attributes.apply { preferredDisplayModeId = mode.modeId }
        Toast.makeText(this, "Hz definido: $hz", Toast.LENGTH_SHORT).show()
    }

    private val tick = object : Runnable {
        override fun run() {
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val th = if (Build.VERSION.SDK_INT >= 29)
                (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus else 0
            val names = listOf("Frio", "Leve", "Moderado", "Severo", "Crítico", "Emergência", "Desligando")
            info.text = "Bateria: $t°C | Térmica: ${names.getOrElse(th) { "?" }}\n" +
                "RAM livre: ${mi.availMem shr 20} MB / ${mi.totalMem shr 20} MB" +
                if (th >= 2) "\n⚠ Aquecendo: baixe os gráficos/FPS do jogo" else ""
            h.postDelayed(this, 2000)
        }
    }

    private fun refresh() {
        list.removeAllViews()
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.applicationInfo }
            .filter {
                it.packageName != packageName && (showAll || it.category == ApplicationInfo.CATEGORY_GAME ||
                    (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
            }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        if (apps.isEmpty()) list.addView(TextView(this).apply { text = "Nenhum jogo achado. Toque em 'Mostrar todos'."; setTextColor(Color.GRAY) })
        apps.forEach { a ->
            list.addView(Button(this).apply {
                text = "▶ " + pm.getApplicationLabel(a)
                setOnClickListener { launch(a.packageName, 0) }
                setOnLongClickListener {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}")))
                    true
                }
            })
        }
    }

    private fun boost(pkg: String) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        packageManager.getInstalledApplications(0).forEach {
            if (it.packageName != packageName && it.packageName != pkg) am.killBackgroundProcesses(it.packageName)
        }
    }

    private fun launch(pkg: String, tries: Int) {
        boost(pkg)
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        if (!hasUsage() || tries >= 3) return
        h.postDelayed({
            if (foreground() != pkg) {
                Toast.makeText(this, "Jogo fechou, reabrindo (${tries + 1}/3)", Toast.LENGTH_SHORT).show()
                launch(pkg, tries + 1)
            }
        }, 8000)
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun foreground(): String? {
        val u = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val e = u.queryEvents(now - 15000, now)
        val ev = UsageEvents.Event(); var last: String? = null
        while (e.hasNextEvent()) { e.getNextEvent(ev); if (ev.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = ev.packageName }
        return last
    }
}
